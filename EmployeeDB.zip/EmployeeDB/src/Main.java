import java.sql.Connection;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
            dbFunctions db = new dbFunctions();
            Connection connection = db.connect_to_db("javacrud");
            //  db.createTable(connection, "employee" );
            //  db.insertInto(connection,"employee","Sangeetha","Bangalore");
            //  db.updateData(connection,"employee","Sangeetha","Bharath");
            //  db.readData(connection,"employee");
            //  db.searchbyname(connection,"employee","Shona");
            //  db.searchbyID(connection,"employee",2);
            //  db.deletebyID(connection,"employee",4);
            //  db.deletebyName(connection,"employee","Bharat");
                db.deletetable(connection,"employee");
        }
    }
