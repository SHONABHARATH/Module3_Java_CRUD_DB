import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class dbFunctions {
    public Connection connect_to_db(String dbname)
    {
         Connection connection = null;
         try
         {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/"+dbname);
            if(connection!=null)
                System.out.println("Connection successfull");
            else
                System.out.println("Connection refused");
         } catch (Exception e) {
             System.out.println(e);

         }
         return connection;
    }
    public void createTable(Connection connection, String tablename)
    {
        Statement statement;
        try{
            String query = "create table " + tablename + "(empid SERIAL, name varchar(200), " +
                                                            "address varchar(200), primary key(empid));";
            statement = connection.createStatement();
            statement.executeUpdate(query);
            System.out.println("Table created");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    public void insertInto(Connection connection, String tablename, String name, String address)
    {
        Statement statement;
        try{
            String query = String.format("insert into  %s(name,address) values('%s','%s');",tablename,name,address);
            statement = connection.createStatement();
            statement.executeUpdate(query);
            System.out.println("Rows Inserted ");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    public void readData(Connection connection, String tablename)
    {
        Statement statement;
        ResultSet rs;
        try{
            String query = String.format("Select * from %s",tablename);
            statement = connection.createStatement();
            rs=statement.executeQuery(query);
            while(rs.next()) {
                System.out.print(rs.getString("empid")+" ");
                System.out.print(rs.getString("Name")+" ");
                System.out.println(rs.getString("Address")+" ");
            }
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    public void updateData(Connection connection, String tablename, String oldname, String newname)
    {
        Statement statement;
        try{
            String query = String.format("update %s set name='%s' where name='%s'",tablename,newname,oldname);
            statement = connection.createStatement();
            statement.executeUpdate(query);
            System.out.print("Data updated");
            }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    public void searchbyname(Connection connection, String tablename, String name)
    {
        Statement statement;
        ResultSet rs=null;
        try{
            String query = String.format("Select * from %s where name = %s",tablename,name );
            statement = connection.createStatement();
            rs=statement.executeQuery(query);
            while(rs.next()) {
                System.out.print(rs.getString("empid")+" ");
                System.out.print(rs.getString("Name")+" ");
                System.out.println(rs.getString("Address")+" ");
            }
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    public void searchbyID(Connection connection, String tablename, int ID)
    {
        Statement statement;
        ResultSet rs=null;
        try{
            String query = String.format("Select * from %s where empid = %s",tablename,ID );
            statement = connection.createStatement();
            rs=statement.executeQuery(query);
            while(rs.next()) {
                System.out.print(rs.getString("empid")+" ");
                System.out.print(rs.getString("Name")+" ");
                System.out.println(rs.getString("Address")+" ");
            }
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    public void deletebyID(Connection connection, String tablename, int ID)
    {
        Statement statement;
        ResultSet rs=null;
        try{
            String query = String.format("Delete from %s where empid = %s",tablename,ID );
            statement = connection.createStatement();
            statement.executeUpdate(query);
                System.out.print( "Data deleted ");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    public void deletebyName(Connection connection, String tablename, String name)
    {
        Statement statement;
        ResultSet rs=null;
        try{
            String query = String.format("Delete from %s where name = %s",tablename,name );
            statement = connection.createStatement();
            statement.executeUpdate(query);
            System.out.print( "Data deleted ");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    public void deletetable(Connection connection, String tablename)
    {
        Statement statement;
        try{
            String query = String.format("drop table %s",tablename );
            statement = connection.createStatement();
            statement.executeUpdate(query);
            System.out.print( "Table deleted ");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }
}
