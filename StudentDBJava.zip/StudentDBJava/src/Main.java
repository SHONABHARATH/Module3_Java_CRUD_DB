import java.sql.Connection;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        dbmethods db = new dbmethods();
        Connection connection = db.dbconnect("javacrudstudentdb");
    //    db.createTable(connection,"studentdb");
    //    db.insertdata(connection,"studentdb","Shona","shona@gmail.com");
    //    db.insertdata(connection,"studentdb","Sangeetha","sangeetha@gmail.com");
     //   db.readData(connection,"studentdb");
     //   db.updateData(connection,"studentdb","Sangeetha","Bharath");
      //  db.searchbyID(connection,"studentdb",1);
        db.deletebyname(connection,"studentdb","Bharath");
        }
    }
