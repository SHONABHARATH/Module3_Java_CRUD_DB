import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class dbmethods {

    public Connection dbconnect(String dbname)  {
        Connection connection=null;
        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/" + dbname);
            if (connection != null)
                System.out.println("Connection successful");
            else
                System.out.println("Connection refused");
            return connection;
        } catch (Exception e) {
            System.out.println(e);
        }
        return connection;
    }

    public void createTable(Connection connection, String tablename)
    {
        Statement statement;
        try {
            String query = "create table " + tablename +  "(empid SERIAL, name varchar(20), "
            + "mail varchar(20), primary key(empid));";
            statement = connection.createStatement();
            statement.executeUpdate(query);
            System.out.println("Table created ");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }

    public void insertdata(Connection connection, String tablename, String name, String mail)
    {
        Statement statement;
        try
        {
            String query = String.format("insert into %s(name,mail) values('%s','%s');",tablename,name, mail);
            statement=connection.createStatement();
            statement.executeUpdate(query);
            System.out.println("Table with values ");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }

        }

        public void readData(Connection connection, String tablename)
        {
            Statement statement;
            ResultSet rs;
            try
            {
                String query = String.format("Select * from %s",tablename);
                statement = connection.createStatement();
                rs=statement.executeQuery(query);
                while(rs.next())
                {
                    System.out.println(rs.getString("empid"));
                    System.out.println(rs.getString("name"));
                    System.out.println(rs.getString("mail"));
                }

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        public void updateData(Connection connection, String tablename, String oldname, String newname)
        {
            Statement statement;
            try
            {
             String query = String.format("Update %s set name = '%s' where name = '%s'",tablename,newname,oldname);
             statement=connection.createStatement();
             statement.executeUpdate(query);

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        public void searchbyID(Connection connection, String tablename, int empid)
        {
            Statement statement;
            ResultSet rs;
            try
            {
                String query = String.format("Select * from %s where empid = %s",tablename,empid);
                statement=connection.createStatement();
                rs= statement.executeQuery(query);
                while(rs.next())
                {
                    System.out.println(rs.getString("empid"));
                    System.out.println(rs.getString("name"));
                    System.out.println(rs.getString("mail"));
                }

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        public void deletebyname(Connection connection, String tablename, String name)
        {
            Statement statement;
            ResultSet rs=null;
            try
            {
                String query = String.format("Delete from %s where name = '%s'",tablename,name);
                statement=connection.createStatement();
                statement.executeUpdate(query);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

    }






